declare namespace NodeJS {
    export interface Global {
      ModLoader: any
    }
  }