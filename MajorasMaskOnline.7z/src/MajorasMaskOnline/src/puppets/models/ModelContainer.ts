export class ModelContainer {
  adult!: Buffer;
  child!: Buffer;
}
