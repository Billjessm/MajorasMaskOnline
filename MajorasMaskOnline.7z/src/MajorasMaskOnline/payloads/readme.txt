Assembly and/or Gameshark codes can be injected at runtime
using the current repository based on any specific version
of the game being targetted.

The Assembly must be converted to Gameshark codes, then any
Gameshark code saved as a file ending with the '.payload' 
extension.

The file will be injected based on the version of the game
by creating a folder named after the version ex:
USA 1.0 may look like E0 in the header of the rom in a hex
editor (at the end of the first 3 lines).
