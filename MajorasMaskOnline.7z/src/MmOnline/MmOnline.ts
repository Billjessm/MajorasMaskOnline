import * as Main from './src/Main';
module.exports = Main.MmOnline;
